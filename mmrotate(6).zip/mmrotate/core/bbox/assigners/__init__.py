# Copyright (c) OpenMMLab. All rights reserved.
from .atss_kld_assigner import ATSSKldAssigner
from .atss_obb_assigner import ATSSObbAssigner
from .convex_assigner import ConvexAssigner
from .max_convex_iou_assigner import MaxConvexIoUAssigner
from .sas_assigner import SASAssigner
from .orthogonal_assigner import OrthogonalAssigner
from .max_ortho_iou_assigner import MaxOrthoIoUAssigner

__all__ = [
    'ConvexAssigner', 'MaxConvexIoUAssigner', 'SASAssigner', 'ATSSKldAssigner',
    'ATSSObbAssigner', 'OrthogonalAssigner', 'MaxOrthoIoUAssigner'
]
